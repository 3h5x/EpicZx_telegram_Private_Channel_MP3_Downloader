// EpicZx - Simple Document ID Download Only
console.log('🎵 EpicZx: Content script loaded - Document ID download only');
