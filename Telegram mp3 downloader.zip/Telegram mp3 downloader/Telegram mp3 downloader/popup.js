document.addEventListener('DOMContentLoaded', () => {
    const documentIdInput = document.getElementById('documentId');
    const downloadSpecificBtn = document.getElementById('downloadSpecific');
    const statusSection = document.getElementById('statusSection');
    const statusText = document.getElementById('statusText');
    const spinner = document.getElementById('spinner');


    downloadSpecificBtn.addEventListener('click', async () => {
        const documentId = documentIdInput.value.trim();
        
        if (!documentId) {
            showStatus('Please enter a document ID', 'error');
            documentIdInput.focus();
            return;
        }

        if (!documentId.match(/^document\d+$/)) {
            showStatus('Invalid document ID format. Expected: document[numbers]', 'error');
            documentIdInput.focus();
            return;
        }

        await downloadByDocumentId(documentId);
    });


    documentIdInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            downloadSpecificBtn.click();
        }
    });

    async function downloadByDocumentId(documentId) {
        showStatus('Preparing to download...', 'loading');
        setButtonsDisabled(true);

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab.url.includes('web.telegram.org')) {
                showStatus('Please navigate to web.telegram.org first', 'error');
                setButtonsDisabled(false);
                return;
            }


            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: 'MAIN',
                func: downloadSpecificDocumentInMainWorld,
                args: [documentId]
            });


            startStatusPolling();

        } catch (error) {
            console.error('Download failed:', error);
            showStatus('Failed to start download: ' + error.message, 'error');
            setButtonsDisabled(false);
        }
    }

    function startStatusPolling() {
        const pollInterval = setInterval(async () => {
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                const results = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: () => {
                        return window.telegramDownloadStatus || null;
                    }
                });

                const status = results[0]?.result;
                if (status) {
                    if (status.type === 'progress') {
                        showStatus(status.message, 'loading');
                    } else if (status.type === 'success') {
                        showStatus('Download completed successfully!', 'success');
                        setButtonsDisabled(false);
                        clearInterval(pollInterval);

                        chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            world: 'MAIN',
                            func: () => { window.telegramDownloadStatus = null; }
                        });
                    } else if (status.type === 'error') {
                        showStatus('Download failed: ' + status.message, 'error');
                        setButtonsDisabled(false);
                        clearInterval(pollInterval);

                        chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            world: 'MAIN',
                            func: () => { window.telegramDownloadStatus = null; }
                        });
                    }
                }
            } catch (error) {
                console.error('Status polling error:', error);
                clearInterval(pollInterval);
                setButtonsDisabled(false);
            }
        }, 500); 


        setTimeout(() => {
            clearInterval(pollInterval);
            setButtonsDisabled(false);
        }, 120000);
    }

    function showStatus(message, type = 'info') {
        statusSection.style.display = 'block';
        statusText.textContent = message;
        

        statusSection.className = 'status-section';
        
        if (type === 'loading') {
            spinner.style.display = 'block';
        } else {
            spinner.style.display = 'none';
            if (type === 'success') {
                statusSection.classList.add('status-success');
            } else if (type === 'error') {
                statusSection.classList.add('status-error');
            }
        }


        if (type === 'success') {
            setTimeout(() => {
                statusSection.style.display = 'none';
            }, 3000);
        }
    }

    function setButtonsDisabled(disabled) {
        downloadSpecificBtn.disabled = disabled;
        documentIdInput.disabled = disabled;
    }


    function downloadSpecificDocumentInMainWorld(documentId) {
        console.log('Starting download for document ID:', documentId);
        

        window.telegramDownloadStatus = {
            type: 'progress',
            message: 'Searching for document URL...'
        };


        const fileUrl = `https://web.telegram.org/a/progressive/${documentId}`;
        
        (async () => {
            const chunkSize = 512000; // 512KB chunks
            let chunks = [];
            let start = 0;
            let done = false;

            try {
                while (!done) {
                    const end = start + chunkSize - 1;

                    window.telegramDownloadStatus = {
                        type: 'progress',
                        message: `Downloading chunk ${Math.floor(start / chunkSize) + 1}...`
                    };

                    console.log(`Downloading bytes ${start}-${end}...`);

                    const response = await fetch(fileUrl, {
                        headers: {
                            'Range': `bytes=${start}-${end}`,
                            'Referer': 'https://web.telegram.org/a/',
                        }
                    });

                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }

                    const contentRange = response.headers.get("Content-Range");
                    const match = contentRange && contentRange.match(/bytes (\d+)-(\d+)\/(\d+)/);
                    
                    if (!match) {
                        throw new Error('Could not determine file size from server response');
                    }

                    const [, rangeStart, rangeEnd, totalLength] = match.map(Number);
                    const chunk = await response.arrayBuffer();
                    chunks.push(chunk);

                    if (rangeEnd >= totalLength - 1) {
                        done = true;
                    } else {
                        start = rangeEnd + 1;
                    }
                }

                window.telegramDownloadStatus = {
                    type: 'progress',
                    message: 'Finalizing download...'
                };


                const fullBlob = new Blob(chunks, { type: 'audio/mpeg' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(fullBlob);
                a.download = `telegram_audio_${documentId}.mp3`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(a.href);

                window.telegramDownloadStatus = {
                    type: 'success',
                    message: 'Download completed successfully!'
                };

            } catch (error) {
                console.error('Download failed:', error);
                window.telegramDownloadStatus = {
                    type: 'error',
                    message: error.message
                };
            }
        })();
    }
}); 